﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UI_Dashboard.Model;
using UI_Dashboard.Repository_DI;

namespace UI_Dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : Controller
    {
        readonly IAdmin admin = null;

        public AdminController(IAdmin admin)
        {
            this.admin = admin;
        }
        [HttpPost]
        public async Task<IActionResult> AdminRegistration(Admin registerAdmin)
        {
            var ar = await admin.Create(registerAdmin);
            return Ok(ar);
        }

        [HttpGet("{id},{Password}")]
        public async Task<IActionResult> AdminLogin(int id, string Password)
        {
            var ar = await admin?.Login(id, Password);
            return Ok(ar);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit(int id, Admin editAdmin)
        {
            var ar = await admin.UpdateAdmin(id, editAdmin);
            return Ok(ar);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ar = await admin.DeleteAdmin(id);
            return Ok(ar);
        }

    }
}
