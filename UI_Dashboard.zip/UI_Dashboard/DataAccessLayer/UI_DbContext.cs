﻿using Microsoft.EntityFrameworkCore;
using UI_Dashboard.Model;

namespace UI_Dashboard.DataAccessLayer
{
    public class UI_DbContext:DbContext
    {
        public UI_DbContext(DbContextOptions<UI_DbContext> options) : base(options)
        {


        }

        public DbSet<Admin> admins { get; set; }
    }
}
