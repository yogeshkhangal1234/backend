﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using UI_Dashboard.DataAccessLayer;
using UI_Dashboard.Model;

namespace UI_Dashboard.Repository_DI
{
        public class AdminRepository : IAdmin
        {
            readonly UI_DbContext ui_DbContext = null;
            public AdminRepository(UI_DbContext ui_DbContext)
            {
                this.ui_DbContext = ui_DbContext;
            }
            public async Task<int> Create(Admin registerAdmin)
            {
                ui_DbContext.Add(registerAdmin);
                await ui_DbContext.SaveChangesAsync();
                return registerAdmin.AdminId;
            }

            public async Task<Admin> DeleteAdmin(int id)
            {
                var ar = await ui_DbContext.admins.Where(x => x.AdminId == id).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ui_DbContext.Remove(ar);
                    await ui_DbContext.SaveChangesAsync();
                }
                return ar;
            }

            public async Task<Admin> Login(int id, string Password)
            {
                var ar = await ui_DbContext.admins.Where(x => x.AdminId == id && x.Password == Password).FirstOrDefaultAsync();
                return ar;
            }

            public async Task<Admin> UpdateAdmin([FromRoute] int id, [FromBody] Admin admin)
            {
                var ar = await ui_DbContext.admins.Where(x => x.AdminId == id).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.Name = admin.Name;
                    ar.Password = admin.Password;
                    ar.ConfirmPassword = admin.ConfirmPassword;
                }
                await ui_DbContext.SaveChangesAsync();
                return admin;
            }
        }
}
