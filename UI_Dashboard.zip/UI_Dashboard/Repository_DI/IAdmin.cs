﻿using System.Threading.Tasks;
using UI_Dashboard.Model;

namespace UI_Dashboard.Repository_DI
{
    public interface IAdmin
    {
        Task<int> Create(Admin registerUser);

        Task<Admin> Login(int id, string Password);

        Task<Admin> UpdateAdmin(int id, Admin user);

        Task<Admin> DeleteAdmin(int id);
    }
}
